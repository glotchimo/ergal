""" ERGAL CLI """

import os
import argparse


print("""
  _  _         |
 |/ |  /| //|  |
        |   

Welcome to ERGAL, the Elegant and Readable General API Library    
""")


